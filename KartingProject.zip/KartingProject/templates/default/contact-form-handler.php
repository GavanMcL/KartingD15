<?php
  $name = $_POST['name'];
  $vistor_email = $_POST['email'];
  $message = $_POST['message'];

  $email_from = 'sendingKarting@gmail.com';

  $email_subject = 'Contact Us Form Submission';

  $email_body =   "Name: $name,\n".
                    "Email: $vistor_email.\n".
                      "Message: $message.\n";

  $to = "receivingKarting@gmail.com";

  $headers = "From: $email_from \r\n";

  $headers .= "Reply-to: $vistor_email \r\n";

  mail($to,$email_subject,$email_body,$headers);

  header("Location: index.html");


 ?>
