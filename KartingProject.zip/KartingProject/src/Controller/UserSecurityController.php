<?php

namespace App\Controller;

use App\Entity\UserSecurity;
use App\Form\UserSecurityType;
use App\Repository\UserSecurityRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;


/**
 * @Route("/admin")
 * @IsGranted("ROLE_ADMIN")
 */
class UserSecurityController extends AbstractController
{
    /**
     * @Route("/", name="admin_index", methods={"GET"})
     */
    public function index(UserSecurityRepository $userSecurityRepository): Response
    {
        return $this->render('user_security/index.html.twig', [
            'user_securities' => $userSecurityRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="admin_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $userSecurity = new UserSecurity();
        $form = $this->createForm(UserSecurityType::class, $userSecurity);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($userSecurity);
            $entityManager->flush();

            return $this->redirectToRoute('user_security_index');
        }

        return $this->render('user_security/new.html.twig', [
            'user_security' => $userSecurity,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="admin_show", methods={"GET"})
     */
    public function show(UserSecurity $userSecurity): Response
    {
        return $this->render('user_security/show.html.twig', [
            'user_security' => $userSecurity,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="admin_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, UserSecurity $userSecurity): Response
    {
        $form = $this->createForm(UserSecurityType::class, $userSecurity);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('user_security_index');
        }

        return $this->render('user_security/edit.html.twig', [
            'user_security' => $userSecurity,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="admin_delete", methods={"DELETE"})
     */
    public function delete(Request $request, UserSecurity $userSecurity): Response
    {
        if ($this->isCsrfTokenValid('delete'.$userSecurity->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($userSecurity);
            $entityManager->flush();
        }

        return $this->redirectToRoute('user_security_index');
    }
}
