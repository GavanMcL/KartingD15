<?php

namespace App\Controller;

use App\Entity\Race;
use App\Form\RaceType;
use App\Repository\RaceRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function index(RaceRepository $raceRepository)
    {
        return $this->render('default/index.html.twig', [
            'races' => $raceRepository->findAll(),
        ]);
    }

    /**
     * @Route("/sitemap", name="sitemap")
     */
    public function sitemap()
    {
        $template = 'default/sitemap.html.twig';
        $args = [];
        return $this->render($template, $args);
    }

    /**
     * @Route("/group", name="group")
     */
    public function group()
    {
        $template = 'default/group.html.twig';
        $args = [];
        return $this->render($template, $args);
    }

    /**
     * @Route("/family", name="family")
     */
    public function family()
    {
        $template = 'default/family.html.twig';
        $args = [];
        return $this->render($template, $args);
    }

    /**
     * @Route("/equipment", name="equipment")
     */
    public function equipment()
    {
        $template = 'default/equipmet.html.twig';
        $args = [];
        return $this->render($template, $args);
    }

    /**
     * @Route("/contact", name="contact")
     */
    public function contact()
    {
        $template = 'default/contact.html.twig';
        $args = [];
        return $this->render($template, $args);
    }
}
