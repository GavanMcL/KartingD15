<?php

namespace App\DataFixtures;

use App\Entity\UserSecurity;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class UserSecurityFixtures extends Fixture
{
    private $passwordEncoder;
    public function __construct(UserPasswordEncoderInterface $passwordEncoder)
    {
        $this->passwordEncoder = $passwordEncoder;
    }

    public function load(ObjectManager $manager)
    {

        $userSecurity2 = new userSecurity();
        $userSecurity2->setEmail('q@hotmail.com');
        $plainPassword ='word';
        $encodedPassword = $this->passwordEncoder->encodePassword($userSecurity2, $plainPassword);
        $userSecurity2->setPassword($encodedPassword);
        $userSecurity2->setRoles(['ROLE_ADMIN','ROLE_STAFF']);
        $manager->persist($userSecurity2);

        $userSecurity1 = new userSecurity();
        $userSecurity1->setEmail('g@hotmail.com');
        $plainPassword ='pass';
        $encodedPassword = $this->passwordEncoder->encodePassword($userSecurity1, $plainPassword);
        $userSecurity1->setPassword($encodedPassword);
        $userSecurity1->setRoles(['ROLE_STAFF']);
        $manager->persist($userSecurity1);

        $userSecurity1 = new userSecurity();
        $userSecurity1->setEmail('a@hotmail.com');
        $plainPassword ='pswrd';
        $encodedPassword = $this->passwordEncoder->encodePassword($userSecurity1, $plainPassword);
        $userSecurity1->setPassword($encodedPassword);
        $userSecurity1->setRoles(['ROLE_USER']);
        $manager->persist($userSecurity1);



        $manager->flush();
    }
}
