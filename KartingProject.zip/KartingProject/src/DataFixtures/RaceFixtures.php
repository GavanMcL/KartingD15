<?php

namespace App\DataFixtures;

use App\Entity\Race;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class RaceFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
         $race1 = new Race();
         $race1->setMaxRacers(10);
         $race1->setLaps(3);
         $manager->persist($race1);

        $race2 = new Race();
        $race2->setMaxRacers(5);
        $race2->setLaps(7);
        $manager->persist($race2);

        $race3 = new Race();
        $race3->setMaxRacers(12);
        $race3->setLaps(5);
        $manager->persist($race3);

        $manager->flush();
    }
}
