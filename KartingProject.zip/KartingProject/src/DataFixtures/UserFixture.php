<?php

namespace App\DataFixtures;

use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class UserFixture extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $user1 = new User();
        $user1->setName('Gav');
        $user1->setEmail('g@hotmail.com');
        $user1->setPassword('pass');
        $user1->setAge(22);
        $user1->setSex('male');
        $user1->setRole('ROLE_ADMIN');
        $manager->persist($user1);

        $user2 = new User();
        $user2->setName('Quincey');
        $user2->setEmail('q@hotmail.com');
        $user2->setPassword('word');
        $user2->setAge(1);
        $user2->setSex('male');
        $user2->setRole('ROLE_STAFF');
        $manager->persist($user2);

        $user3 = new User();
        $user3->setName('Kayleigh');
        $user3->setEmail('k@hotmail.com');
        $user3->setPassword('pswrd');
        $user3->setAge(42);
        $user3->setSex('female');
        $user3->setRole('ROLE_USER');
        $manager->persist($user3);

        $manager->flush();
    }
}
