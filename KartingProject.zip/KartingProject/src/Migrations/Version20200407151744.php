<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200407151744 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE test_race_test_user DROP FOREIGN KEY FK_2E204496B21800C5');
        $this->addSql('ALTER TABLE test_race_test_user DROP FOREIGN KEY FK_2E2044967B2F075D');
        $this->addSql('DROP TABLE test_race');
        $this->addSql('DROP TABLE test_race_test_user');
        $this->addSql('DROP TABLE test_user');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE test_race (id INT AUTO_INCREMENT NOT NULL, laps_completed VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, avg_time DOUBLE PRECISION NOT NULL, finished VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('CREATE TABLE test_race_test_user (test_race_id INT NOT NULL, test_user_id INT NOT NULL, INDEX IDX_2E2044967B2F075D (test_user_id), INDEX IDX_2E204496B21800C5 (test_race_id), PRIMARY KEY(test_race_id, test_user_id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('CREATE TABLE test_user (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, email VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, pass VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, age INT NOT NULL, sex VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, role VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE test_race_test_user ADD CONSTRAINT FK_2E2044967B2F075D FOREIGN KEY (test_user_id) REFERENCES test_user (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE test_race_test_user ADD CONSTRAINT FK_2E204496B21800C5 FOREIGN KEY (test_race_id) REFERENCES test_race (id) ON DELETE CASCADE');
    }
}
