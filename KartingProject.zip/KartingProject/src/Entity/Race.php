<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\RaceRepository")
 */
class Race
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $MaxRacers;

    /**
     * @ORM\Column(type="integer")
     */
    private $Laps;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMaxRacers(): ?int
    {
        return $this->MaxRacers;
    }

    public function setMaxRacers(int $MaxRacers): self
    {
        $this->MaxRacers = $MaxRacers;

        return $this;
    }

    public function getLaps(): ?int
    {
        return $this->Laps;
    }

    public function setLaps(int $Laps): self
    {
        $this->Laps = $Laps;

        return $this;
    }
}
